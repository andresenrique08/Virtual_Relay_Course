import numpy as np
import matplotlib.pylab as plt

n = 128 # number of point in the whole interval
f = 200.0 #  frequency in Hz
dt = 1 / (f * 32 ) #32 samples per unit frequency
t = np.linspace( 0, (n-1)*dt, n)


y = np.cos(2 * np.pi * f * t) - 0.4 * np.sin(2 * np.pi * (2*f) * t )
print dt
t1 =np.arange(n)
#plt.plot(t,y)
#plt.show()

def fourier(x):
	
	l=len(x)
	d =np.arange(l)
	e=[]
	tot= []
	r=[]
	c=0
	for k in range(l):
		ex=np.exp(-1j*2*np.pi*k*d/l)
		c+=(x[k]*ex)
		f=np.asarray(c)
		
		
	return f/l
#plt.plot(np.abs(fourier(y)))
#plt.show()

def frec(x,dt):
	
	f=[]
	o=len(x)
	h=dt*o
	if o%2==0:
		r=range(o/2)
		g=range((-o/2),0)
		f=r+g
		
	else:	
		r=range(o-1/2)
		g=range((-(o-1)/2),0)
		f=r+g
	
	return np.asarray(f)/np.asarray(h)

plt.plot(frec(t,dt),np.abs(fourier(y)))
plt.show()


#print(freq)
#print t1
#plt.plot(np.abs(fourier(y)/n))# plote 
#plt.show()



# Lo siguiente es para verificar que el codigo este bien:
from scipy.fftpack import fft, fftfreq
fft_x = fft(y) / n # FFT Normalized
freq = fftfreq(n, dt) # Recuperamos las frecuencias
#plt.plot(freq,np.abs(fft_x)) 
#plt.show()


